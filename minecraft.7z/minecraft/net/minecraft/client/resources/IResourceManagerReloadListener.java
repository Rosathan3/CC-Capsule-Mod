package net.minecraft.client.resources;

import net.minecraft.client.resources.IResourceManager;

public interface IResourceManagerReloadListener {

   void func_110549_a(IResourceManager var1);
}
