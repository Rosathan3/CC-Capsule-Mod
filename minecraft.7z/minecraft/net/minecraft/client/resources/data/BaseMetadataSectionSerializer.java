package net.minecraft.client.resources.data;

import net.minecraft.client.resources.data.IMetadataSectionSerializer;

public abstract class BaseMetadataSectionSerializer implements IMetadataSectionSerializer {

   private static final String __OBFID = "CL_00001098";


}
