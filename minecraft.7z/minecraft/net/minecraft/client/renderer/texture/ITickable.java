package net.minecraft.client.renderer.texture;


public interface ITickable {

   void func_110550_d();
}
