package net.minecraft.client.renderer.texture;

import java.io.IOException;
import net.minecraft.client.resources.IResourceManager;

public interface ITextureObject {

   void func_110551_a(IResourceManager var1) throws IOException;

   int func_110552_b();
}
