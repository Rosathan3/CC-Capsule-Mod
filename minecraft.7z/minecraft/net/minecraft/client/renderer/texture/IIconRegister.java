package net.minecraft.client.renderer.texture;

import net.minecraft.util.IIcon;

public interface IIconRegister {

   IIcon func_94245_a(String var1);
}
