package net.minecraft.client.renderer;

import java.awt.image.BufferedImage;

public interface IImageBuffer {

   BufferedImage func_78432_a(BufferedImage var1);

   void func_152634_a();
}
