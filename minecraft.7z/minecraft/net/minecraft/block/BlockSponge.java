package net.minecraft.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class BlockSponge extends Block {

   private static final String __OBFID = "CL_00000311";


   protected BlockSponge() {
      super(Material.field_151583_m);
      this.func_149647_a(CreativeTabs.field_78030_b);
   }
}
