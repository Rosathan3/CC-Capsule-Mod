package net.minecraft.block.material;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class MaterialLiquid extends Material {

   private static final String __OBFID = "CL_00000541";


   public MaterialLiquid(MapColor p_i2114_1_) {
      super(p_i2114_1_);
      this.func_76231_i();
      this.func_76219_n();
   }

   public boolean func_76224_d() {
      return true;
   }

   public boolean func_76230_c() {
      return false;
   }

   public boolean func_76220_a() {
      return false;
   }
}
