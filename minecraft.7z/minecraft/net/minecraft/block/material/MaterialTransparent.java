package net.minecraft.block.material;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class MaterialTransparent extends Material {

   private static final String __OBFID = "CL_00000540";


   public MaterialTransparent(MapColor p_i2113_1_) {
      super(p_i2113_1_);
      this.func_76231_i();
   }

   public boolean func_76220_a() {
      return false;
   }

   public boolean func_76228_b() {
      return false;
   }

   public boolean func_76230_c() {
      return false;
   }
}
