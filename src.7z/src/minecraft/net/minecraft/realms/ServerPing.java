package net.minecraft.realms;


public class ServerPing {

   public volatile String nrOfPlayers = "0";
   public volatile long lastPingSnapshot = 0L;
   private static final String __OBFID = "CL_00001860";


}
