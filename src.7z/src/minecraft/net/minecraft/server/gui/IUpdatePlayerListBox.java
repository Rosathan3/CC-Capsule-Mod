package net.minecraft.server.gui;


public interface IUpdatePlayerListBox {

   void func_73660_a();
}
