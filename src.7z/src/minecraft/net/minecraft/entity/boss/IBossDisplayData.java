package net.minecraft.entity.boss;

import net.minecraft.util.IChatComponent;

public interface IBossDisplayData {

   float func_110138_aP();

   float func_110143_aJ();

   IChatComponent func_145748_c_();
}
