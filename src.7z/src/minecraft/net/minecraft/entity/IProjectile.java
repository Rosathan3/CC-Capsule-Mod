package net.minecraft.entity;


public interface IProjectile {

   void func_70186_c(double var1, double var3, double var5, float var7, float var8);
}
