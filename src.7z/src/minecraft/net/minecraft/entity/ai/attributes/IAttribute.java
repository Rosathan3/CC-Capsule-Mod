package net.minecraft.entity.ai.attributes;


public interface IAttribute {

   String func_111108_a();

   double func_111109_a(double var1);

   double func_111110_b();

   boolean func_111111_c();
}
