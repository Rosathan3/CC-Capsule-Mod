package net.minecraft.entity;

import net.minecraft.entity.EntityLivingBase;

public interface IRangedAttackMob {

   void func_82196_d(EntityLivingBase var1, float var2);
}
