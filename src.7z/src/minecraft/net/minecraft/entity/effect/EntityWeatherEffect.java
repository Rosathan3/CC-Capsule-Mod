package net.minecraft.entity.effect;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public abstract class EntityWeatherEffect extends Entity {

   private static final String __OBFID = "CL_00001665";


   public EntityWeatherEffect(World p_i1702_1_) {
      super(p_i1702_1_);
   }
}
