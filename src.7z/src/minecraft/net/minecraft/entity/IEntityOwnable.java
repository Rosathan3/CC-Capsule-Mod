package net.minecraft.entity;

import net.minecraft.entity.Entity;

public interface IEntityOwnable {

   String func_152113_b();

   Entity func_70902_q();
}
