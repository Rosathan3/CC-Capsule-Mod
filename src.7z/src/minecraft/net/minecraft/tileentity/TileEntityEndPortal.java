package net.minecraft.tileentity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityEndPortal extends TileEntity {

   private static final String __OBFID = "CL_00000365";


}
