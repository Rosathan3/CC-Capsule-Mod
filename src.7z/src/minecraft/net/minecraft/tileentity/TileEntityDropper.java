package net.minecraft.tileentity;

import net.minecraft.tileentity.TileEntityDispenser;

public class TileEntityDropper extends TileEntityDispenser {

   private static final String __OBFID = "CL_00000353";


   public String func_145825_b() {
      return this.func_145818_k_()?this.field_146020_a:"container.dropper";
   }
}
