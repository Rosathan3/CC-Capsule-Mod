package net.minecraft.profiler;

import net.minecraft.profiler.PlayerUsageSnooper;

public interface IPlayerUsage {

   void func_70000_a(PlayerUsageSnooper var1);

   void func_70001_b(PlayerUsageSnooper var1);

   boolean func_70002_Q();
}
