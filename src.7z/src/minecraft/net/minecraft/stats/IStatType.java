package net.minecraft.stats;


public interface IStatType {

   String func_75843_a(int var1);
}
