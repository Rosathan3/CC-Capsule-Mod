package net.minecraft.stats;


public interface IStatStringFormat {

   String func_74535_a(String var1);
}
