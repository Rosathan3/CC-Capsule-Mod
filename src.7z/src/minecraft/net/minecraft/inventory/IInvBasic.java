package net.minecraft.inventory;

import net.minecraft.inventory.InventoryBasic;

public interface IInvBasic {

   void func_76316_a(InventoryBasic var1);
}
