package net.minecraft.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemSimpleFoiled extends Item {

   private static final String __OBFID = "CL_00000065";


   public boolean func_77636_d(ItemStack p_77636_1_) {
      return true;
   }
}
