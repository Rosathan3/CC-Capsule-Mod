package net.minecraft.item.crafting;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;

public class RecipesFood {

   private static final String __OBFID = "CL_00000084";


   public void func_77608_a(CraftingManager p_77608_1_) {
      p_77608_1_.func_77596_b(new ItemStack(Items.field_151009_A), new Object[]{Blocks.field_150338_P, Blocks.field_150337_Q, Items.field_151054_z});
      p_77608_1_.func_92103_a(new ItemStack(Items.field_151106_aX, 8), new Object[]{"#X#", Character.valueOf('X'), new ItemStack(Items.field_151100_aR, 1, 3), Character.valueOf('#'), Items.field_151015_O});
      p_77608_1_.func_92103_a(new ItemStack(Blocks.field_150440_ba), new Object[]{"MMM", "MMM", "MMM", Character.valueOf('M'), Items.field_151127_ba});
      p_77608_1_.func_92103_a(new ItemStack(Items.field_151081_bc), new Object[]{"M", Character.valueOf('M'), Items.field_151127_ba});
      p_77608_1_.func_92103_a(new ItemStack(Items.field_151080_bb, 4), new Object[]{"M", Character.valueOf('M'), Blocks.field_150423_aK});
      p_77608_1_.func_77596_b(new ItemStack(Items.field_151158_bO), new Object[]{Blocks.field_150423_aK, Items.field_151102_aT, Items.field_151110_aK});
      p_77608_1_.func_77596_b(new ItemStack(Items.field_151071_bq), new Object[]{Items.field_151070_bp, Blocks.field_150338_P, Items.field_151102_aT});
      p_77608_1_.func_77596_b(new ItemStack(Items.field_151065_br, 2), new Object[]{Items.field_151072_bj});
      p_77608_1_.func_77596_b(new ItemStack(Items.field_151064_bs), new Object[]{Items.field_151065_br, Items.field_151123_aH});
   }
}
