package net.minecraft.command;

import java.util.List;
import java.util.Map;
import net.minecraft.command.ICommandSender;

public interface ICommandManager {

   int func_71556_a(ICommandSender var1, String var2);

   List func_71558_b(ICommandSender var1, String var2);

   List func_71557_a(ICommandSender var1);

   Map func_71555_a();
}
